package com.example.associacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
public class AssociacaoApplication {
	public static void main(String[] args) {
		SpringApplication.run(AssociacaoApplication.class, args);
	}
        
      
}

package com.example.associacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssociacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
